from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt


def charger_jeu(dossier, nom):
    """
    Charge un fichier de données du TP.

    Paramètres
    ----------
    dossier : str ou pathlib.Path
        Dossier racine contenant le sous-dossier ``data``.
    nom : str
        Nom du jeu, sans extension ``.npz``.

    Retour
    ------
    donnees : dict
        Dictionnaire de tableaux NumPy. Les champs principaux sont
        ``t_fit``, ``y_fit``, ``sigma_fit``, ``t_val`` et ``y_val``.
    """
    p = Path(dossier) / "data" / f"{nom}.npz"
    with np.load(p, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def signal_cos(t, amplitudes, frequences, phases=None):
    """
    Évalue une somme de cosinus.

    ``t`` contient n instants, ``amplitudes`` et ``frequences`` contiennent K
    paramètres. Le résultat est un vecteur de taille n.
    """
    t = np.asarray(t, dtype=float)
    a = np.asarray(amplitudes, dtype=float)
    f = np.asarray(frequences, dtype=float)
    if phases is None:
        phases = np.zeros_like(f)
    phases = np.asarray(phases, dtype=float)
    return np.sum(
        a[None, :] * np.cos(2 * np.pi * t[:, None] * f[None, :] + phases[None, :]),
        axis=1,
    )


def tracer_jeux(jeux, ordre):
    """Affiche les données d'estimation et de validation de plusieurs jeux."""
    fig, axes = plt.subplots(len(ordre), 1, figsize=(9, 2.7 * len(ordre)), sharex=False)
    if len(ordre) == 1:
        axes = [axes]
    for ax, nom in zip(axes, ordre):
        d = jeux[nom]
        ax.plot(d["t_fit"], d["y_fit"], ".", ms=4, label="estimation")
        ax.plot(d["t_val"], d["y_val"], "x", ms=4, label="validation")
        ax.set_title(nom.replace("_", " "))
        ax.set_xlabel("temps t (s)")
        ax.set_ylabel("signal")
        ax.grid(alpha=0.25)
        ax.legend(loc="upper right")
    plt.tight_layout()
    plt.show()


def rmse(y_true, y_pred):
    """Retourne la racine de l'erreur quadratique moyenne."""
    y_true = np.asarray(y_true, float)
    y_pred = np.asarray(y_pred, float)
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def seuil_doux(v, tau):
    """Applique le seuillage doux composante par composante."""
    v = np.asarray(v, float)
    return np.sign(v) * np.maximum(np.abs(v) - tau, 0.0)


def coherence_colonnes(D):
    """
    Retourne la cohérence mutuelle d'un dictionnaire.

    Après normalisation des colonnes d_j, la cohérence vaut
    max_{j != k} |d_j^T d_k|. Elle appartient à [0,1]. Elle n'est pas un
    nombre de conditionnement global, mais une valeur proche de 1 révèle au
    moins une paire de colonnes presque colinéaires.
    """
    D = np.asarray(D, float)
    normes = np.linalg.norm(D, axis=0)
    Dn = D / np.maximum(normes, 1e-15)
    G = np.abs(Dn.T @ Dn)
    np.fill_diagonal(G, 0.0)
    return float(np.max(G)) if G.size else 0.0


def conditionnement_paire_depuis_coherence(mu):
    """
    Convertit une corrélation mu en conditionnement de la paire normalisée.

    Pour deux colonnes unitaires dont la corrélation absolue vaut mu<1, le
    nombre de conditionnement spectral du sous-dictionnaire à deux colonnes vaut
    sqrt((1+mu)/(1-mu)). Cette quantité est seulement un diagnostic local.
    """
    mu = float(mu)
    if mu >= 1.0:
        return np.inf
    return float(np.sqrt((1.0 + mu) / max(1.0 - mu, 1e-15)))


def pseudo_huber(r, delta=1.0):
    """Valeur de la perte pseudo-Huber appliquée composante par composante."""
    r = np.asarray(r, float)
    return delta**2 * (np.sqrt(1.0 + (r / delta) ** 2) - 1.0)


def psi_pseudo_huber(r, delta=1.0):
    """Dérivée de la perte pseudo-Huber par rapport au résidu."""
    r = np.asarray(r, float)
    return r / np.sqrt(1.0 + (r / delta) ** 2)
